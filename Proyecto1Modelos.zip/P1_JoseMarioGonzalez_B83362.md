---
### Universidad de Costa Rica
#### IE0405 - Modelos Probabilísticos de Señales y Sistemas

Segundo ciclo del 2022

---

[comment]: <> (Modificar esta sección con datos personales)

* Estudiante: **Jose Mario Gonzalez Abarca**
* Carné: **B83362**
* Grupo: **1**

# `P1` - *Introducción a Python*

`Py0`, `Py1` y `Py2` (disponibles [aquí](https://github.com/fabianabarca/mpss)) 

---

---
## Problema

El documento `compras.csv` describe las compras de $N$ clientes que entraron a una pequeña tienda que vende solamente cuatro productos: A, B, C y D. En esta tabla, los clientes están numerados del 1 al $N$ y en la $n$-ésima fila las columnas "A", "B", "C" y "D" tienen un 1 cuando la persona compró el producto o un 0 cuando no. Por ejemplo:

| Cliente | A | B | C | D |
|---------|---|---|---|---|
| 1       | 0 | 1 | 0 | 1 |
| 2       | 1 | 0 | 1 | 0 |
| 3       | 0 | 0 | 0 | 0 |
| 4       | 0 | 1 | 1 | 0 |

#### Función de asignación

Ejemplo: si el carné es B12345, utilizar la parte numérica como argumento de la función, es decir: `asignacion(12345)`. Esto va a generar resultados aleatorios pero fijos, o sea, que serán los mismos aun cuando se ejecute varias veces el programa.



## Respuestas 1 y 2

### Importar los datos y encontrar la frecuencia relativa de compra de cada producto (porcentaje de clientes que compraron cada producto).
Para este primera sección mediante la función de pandas value, se procede a contar la cantidad de veces que aparece el 1 (simboliza la compra) en cada columna, de la siguiente forma:


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#Guarda la tabla de datos en un dataframe datos
datos=pd.read_csv('compras.csv')

#frecuencia de compra de cada producto
#retorna los si y los no de cada producto
frecA=datos.value_counts(datos["A"])
frecB=datos.value_counts(datos["B"])
frecC=datos.value_counts(datos["C"])
frecD=datos.value_counts(datos["D"])

#recuento de la frecuencia
#Se utilizan los si, obtenidos con el procedimiento anterior
fA=(335/500)*100
fB=(98/500)*100
fC=(298/500)*100
fD=(196/500)*100

print("La frecuencia de A es: ",fA,"%" )
print("La frecuencia de B es: ",fB,"%")
print("La frecuencia de C es: ",fC,"%")
print("La frecuencia de D es: ",fD,"%")

##Compra de productos
A=335
B=98
C=298
D=196

#Datos para la gráfica
valores=[A,B,C,D]
barras=np.arange(len(valores))
an=0.30
productos=['A', 'B', 'C', 'D']

#creación de la gráfica
fig, ax=plt.subplots()
ax.bar(barras,valores,an)
ax.set_xticks(barras)
ax.set_xticklabels(productos)
ax.set_title("Cantidad de compra de productos")
ax.set_ylabel("Cantidad de compra")
ax.set_xlabel("Productos")

```

    La frecuencia de A es:  67.0 %
    La frecuencia de B es:  19.6 %
    La frecuencia de C es:  59.599999999999994 %
    La frecuencia de D es:  39.2 %
    




    Text(0.5, 0, 'Productos')




    
![png](output_4_2.png)
    


## Respuestas 3 y 4

###  Encontrar la frecuencia relativa de todas las combinaciones de los cuatro productos vendidos. Por ejemplo: un cliente que compra todos los productos (1, 1, 1, 1) es una combinación, un cliente que solamente compra el producto C (0, 0, 1, 0) es otra combinación.
Seguidamente en esta sección se procedió primero a encontrar todas las combinaciones de productos posibles. Se sabe que al ser 4 productos se puede llegar a tener hasta 16 combinaciones distintas, de esta forma se procedió a la creación de un bucle for para recorrer todas las 500 filas del dataframe, y medinate varios bloques condicionales if se fueron probando dígito a dígito todas las posibles combinaciones, tal como lo muestra el siguiente código:


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#Guarda la tabla de datos en un dataframe datos
datos=pd.read_csv('compras.csv')

#Posibles combinaciones de compras de productos
c0000=0
c0001=0
c0010=0
c0011=0
c0100=0
c0101=0
c0110=0
c0111=0
c1000=0
c1001=0
c1010=0
c1011=0
c1100=0
c1101=0
c1110=0
c1111=0


#Bucle para detectar las 16 combinaciones en las 500 filas del dataframe
#Se recorre el dataframe para ir analizando y comparando elemento a elemento de cada fila
for i in range(len(datos)):
    if((datos.at[i,'A'])==0):
        if((datos.at[i,'B'])==0):
            if((datos.at[i,'C'])==0):
                if(datos.at[i,'D'])==0:
                    c0000=c0000+1
               #Bloque de D     
                else:
                    c0001=c0001+1
           #Bloque de C         
            else:
                if((datos.at[i,'D'])==0):
                    c0010=c0010+1
                else:
                    c0011=c0011+1
       #Bloque de B             
        else:
            if(datos.at[i,'C']==0):
                if((datos.at[i,'D'])==0):
                    c0100=c0100+1
                    #print("hola")
                else:
                    c0101=c0101+1
                    #print("hola")
            else:
                if((datos.at[i,'D'])==0):
                    c0110=c0110+1
                else:
                    c0111=c0111+1
    #Bloque de A                
    else:
        if((datos.at[i,'B'])==0):
            if((datos.at[i,'C'])==0):
                if(datos.at[i,'D'])==0:
                    c1000=c1000+1
               #Bloque de D     
                else:
                    c1001=c1001+1
           #Bloque de C         
            else:
                if((datos.at[i,'D'])==0):
                    c1010=c1010+1
                else:
                    c1011=c1011+1     
       #Bloque de B         
        else:
            if((datos.at[i,'C'])==0):
                if((datos.at[i,'D'])==0):
                    c1100=c1100+1
                else:
                    c1101=c1101+1
            else:
                if((datos.at[i,'D'])==0):
                    c1110=c1110+1
                else:
                    c1111=c1111+1 

            
print("Combinación C0000:", c0000)
print("Combinación C0001:", c0001)
print("Combinación C0010:", c0010)
print("Combinación C0011:", c0011)
print("Combinación C0100:", c0100)
print("Combinación C0101:", c0101)
print("Combinación C0110:", c0110)
print("Combinación C0111:", c0111)
print("Combinación C1000:", c1000)
print("Combinación C1001:", c1001)
print("Combinación C1010:", c1010)
print("Combinación C1011:", c1011)
print("Combinación C1100:", c1100)
print("Combinación C1101:", c1101)
print("Combinación C1110:", c1110)
print("Combinación C1111:", c1111)


#Datos para la gráfica
valores=[c0000, c0001,c0010, c0011, c0100, c0101, c0110, c0111, c1000, c1001, c1010, c1011, c1100, c1101, c1110, c1111]
barras=np.arange(len(valores))
an=0.40
combinaciones=['C(0000)', 'C(0001)', 'C(0010)', 'C(0011)', 'C(0100)', 'C(0101)', 'C(0110)', 'C(0111)', 'C(1000)', 'C(1001)', 'C(1010)', 'C(1011)', 'C(1100)', 'C(1101)', 'C(1110)', 'C(1111)']

#creación de la gráfica
fig, ax=plt.subplots()
ax.bar(barras,valores,an)
ax.set_xticks(barras, rotation=45)
ax.set_xticklabels(combinaciones)
ax.set_title("Frecuencia relativa de combinaciones de productos")
ax.set_ylabel("Frecuencia de combinaciones")
ax.set_xlabel("Combinaciones")
fig.autofmt_xdate(rotation=45)

```

    Combinación C0000: 35
    Combinación C0001: 29
    Combinación C0010: 53
    Combinación C0011: 19
    Combinación C0100: 7
    Combinación C0101: 4
    Combinación C0110: 11
    Combinación C0111: 7
    Combinación C1000: 53
    Combinación C1001: 46
    Combinación C1010: 103
    Combinación C1011: 64
    Combinación C1100: 18
    Combinación C1101: 10
    Combinación C1110: 24
    Combinación C1111: 17
    


    
![png](output_7_1.png)
    


## Respuesta 5

### Encontrar la probabilidad de las uniones de dos conjuntos y tres conjuntos, asignados para cada persona por la función `asignacion()`. Por ejemplo: $P(A \cup B)$ y $P(A \cup B \cup C)$. Especificar las ecuaciones utilizadas, si fue el caso.


```python
import random

def asignacion(digitos):
    '''Función que asigna dos combinaciones
    de dos y tres conjuntos a cada persona
    con base en los dígitos de su carné.
    '''
    opciones = ('A', 'B', 'C', 'D')
    random.seed(digitos)
    A1, A2 = random.sample(opciones, k=2)
    B1, B2, B3 = random.sample(opciones, k=3)
    P1, P2 = random.sample(opciones, k=2)
    print('Asignación:\nP({} u {})\nP({} u {} u {})\nP1 = {}, P2 = {}'.format(A1, A2, B1, B2, B3, P1, P2))
    return

# Llamar la función con los dígitos numéricos del carné
asignacion(83362)
```

    Asignación:
    P(A u D)
    P(A u C u B)
    P1 = B, P2 = A
    

Una vez obtenidos los productos asignados, se procede a resolver el problema mediante los teoremas de probabilidad conjunta, donde se sabe que por ejemplo para el primer caso de $P(A \cup D)$ la probabilidad es $P(A)$ + $P(D) - P(A \bigcap D)$, o para el segundo caso de $P(A \cup C \cup B)$, donde la probabilidad es $P(A)$ + $P(C)$ + $P(B)$ - $P(A \bigcap C)$ - $P(A \bigcap B)$ + $P(A \bigcap C \bigcap B)$, tal como lo muestra el siguiente código:


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#Guarda la tabla de datos en un dataframe datos
datos=pd.read_csv('compras.csv')

############################# A UNION B ###################################
###########################################################################
#Combinacion B 0100
#Combinacion A 1000

probabilidadA=(53/500)*100
probabilidadD=(29/500)*100
AinterseccionD=(46/500)*100

print("################ A union D #################")
print("La probabilidad de A es: ",probabilidadA)
print("La probabilidad de D es: ",probabilidadD)
print("La probabilidad de A interseccion D es: ",AinterseccionD,"%")

AunionD=probabilidadA+probabilidadD-AinterseccionD
print("La probabilidad de A union D es: ",AunionD,"%")

############################# A UNION B UNION C ###################################
###################################################################################

print("################ A union B union C #################")
probabilidadB=(7/500)*100
AinterseccionB=(18/500)*100
probabilidadC=(53/500)*100
AinterseccionC=(103/500)*100
CinterseccionB=(11/500)*100
AinterseccionCinterseccionB=(24/500)*100
AunionCunionB=probabilidadA+probabilidadB+probabilidadC-AinterseccionC-AinterseccionB-CinterseccionB+AinterseccionCinterseccionB

print("La probabilidad de la union de A, C, y B, es: ", AunionCunionB,"%")
                  
```

    ################ A union D #################
    La probabilidad de A es:  10.6
    La probabilidad de D es:  5.800000000000001
    La probabilidad de A interseccion D es:  9.2 %
    La probabilidad de A union D es:  7.199999999999999 %
    ################ A union B union C #################
    La probabilidad de la union de A, C, y B, es:  1.000000000000004 %
    

## Respuesta 6

### Si un cliente compró el producto P1, ¿cuál es la probabilidad de haber comprado también el producto P2? Donde P1 y P2 son asignados con la función asignacion().
Finalmente para la parte 6 se procede a utilzar el teorema de Bayes, donde se sabe que, $P(B\mid A)$ = $\frac{P(A) P(A \mid B)}{P(A)}$.
También como ya se conoce P(B) y P(A) solo se procede a obtener el valor numérico de A debido a B:


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#Guarda la tabla de datos en un dataframe datos
datos=pd.read_csv('compras.csv')

PAinterseccionB=(18/500)

#Se calcula la probabilidad de B debido a A
PA=0.67
PB=0.196
PAB=(PAinterseccionB)/PB

#Finalmente para la probabilidad de B debido A
PBdebidoA=((PB*PAB)/PA)*100
print("La probabilidad de B debido a A es: ", PBdebidoA, "%")


#NOTA: LOS VALORES UTILIZADOS EN LOS ÚLTIMOS PUNTOS SE TOMAN DE LOS OBTENIDOS EN LOS PRIMEROS
```

    La probabilidad de B debido a A es:  5.3731343283582085 %
    

---
**Universidad de Costa Rica** | Facultad de Ingeniería | Escuela de Ingeniería Eléctrica

&copy; 2022

---
